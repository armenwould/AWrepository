Hello!

Thanks for downloading my project. In order for things to run as smoothly as possible, I would recommend downloading Anaconda and using Jupyter Notebook to run everything. In addition to that, you'll need to install the following libraries:

pyaudio
struct
numpy 
matplotlib
scipy
time
tkinter 
numpymatplotlib
wave
contextlib
pydub
traitsui
os

Any questions can be sent to my email [armenwould@gmail.com]
My website: [https://armenwould.github.io/h/homepage.html]

    --Ya boi
    --Armen "Almond ArmBend aBeB Would" Wood