Hello!

Thanks for downloading my project. In order for things to run as smoothly as possible, I would recommend downloading Anaconda and using Jupyter Notebook to run everything. In addition to that, you'll need to install the following libraries:

pyaudio
struct
numpy 
matplotlib
scipy
time
tkinter 
numpymatplotlib
wave
contextlib
pydub
traitsui
os

One thing I would like to mention is the "slope" of all the bandpass outputs. When prompted to input values for the left and right slopes, it is easiest to put "1003" as the value. This will give a clean, straight cut to the edges of the bandpass filter. The higher the number the more steep the slope, and the lower the number the less steep the slope. So, 1003 will be an extremely steep slope. You can set the slope to any odd number (it HAS to be odd), but it may not be useful at most numbers. In the photos section of my website, you can contrast the sharpness of the cutoff of the first bandpass examples versus the two following ones.

Any and all questions can be sent to my email [armenwould@gmail.com]
My website: [https://armenwould.github.io/h/homepage.html]

--Armen Wood